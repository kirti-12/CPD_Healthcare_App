import json
import os
import requests
from dotenv import load_dotenv
from flask import Flask, request, session, render_template, flash,redirect,url_for 
from requests.auth import HTTPBasicAuth
import smtplib
from email.message import EmailMessage
import uuid
from datetime import timedelta
from flask import session, app
from flask import send_from_directory
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import tensorflow as tf
import numpy as np

app = Flask(__name__)

@app.before_request
def make_session_permanent():
    session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=5)



app.config.update(dict(
    DEBUG=True,
    SECRET_KEY=os.environ.get('SECRET_KEY', 'development key')
))

strings = {
    
    "Gender": ["Female", "Male"],
    
}

# min, max, default value
floats = {
    "Weight": [10, 110, 50],
    "TSH": [1,100, 1],
    "Cholestrol": [80, 300, 125],
    "Hb": [1, 20, 14]
}

# min, max, default value
ints = {
    "Age": [10, 100, 45],
    "BP_Upper": [50, 300, 122],
    "BP_Lower": [10,200, 85],
    "Glucose_Fasting": [50, 300, 80],
    "Glucose_PP": [50, 600,120 ]
}

health_status = ["Unhealthy", "Healthy"]

def send_mail(name,regID,send_from , send_to , mail_password):
    msg = EmailMessage()
    mail_body=f"""Hi {name}! You have succesfully registered to TrustMe App! Your new registration no. is {regID}"""
    msg.set_content(mail_body)
    mail_subject="Registration Complete-TrustMe App"
    msg['Subject'] = mail_subject
    msg['From'] = send_from
    msg['To'] = send_to

    # Send the message via our own SMTP server.
    server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
    # server.starttls()
    server.login(send_from , mail_password)
    server.send_message(msg)
    server.quit()


def generate_input_lines():
    result = f'<table>'

    counter = 0
    for k in floats.keys():
        minn, maxx, vall = floats[k]
        if (counter % 2 == 0):
            result += f'<tr>'
        result += f'<td>{k}'
        result += f'<input type="number" class="form-control" min="{minn}" max="{maxx}" step="1" name="{k}" id="{k}" value="{vall}" required (this.value)">'
        result += f'</td>'
        if (counter % 2 == 1):
            result +=f'</tr>'
        counter = counter + 1

    counter = 0
    for k in ints.keys():
        minn, maxx, vall = ints[k]
        if (counter % 2 == 0):
            result += f'<tr>'
        result += f'<td>{k}'
        result += f'<input type="number" class="form-control" min="{minn}" max="{maxx}" step="1" name="{k}" id="{k}" value="{vall}" required (this.value)">'
        result += f'</td>'
        if (counter % 2 == 1):
            result += f'</tr>'
        counter = counter + 1

    counter = 0
    for k in strings.keys():
        if (counter % 2 == 0):
            result += f'<tr>'
        result += f'<td>{k}'
        result += f'<select class="form-control" name="{k}">'
        for value in strings[k]:
            result += f'<option value="{value}" selected>{value}</option>'
        result += f'</select>'
        result += f'</td>'
        if (counter % 2 == 1):
            result += f'</tr>'
        counter = counter + 1

    result += f'</table>'

    return result
    


app.jinja_env.globals.update(generate_input_lines=generate_input_lines)


def get_token():
    auth_token = os.environ.get('AUTH_TOKEN')
    api_token = os.environ.get("API_TOKEN")
    token_request_url = os.environ.get("TOKEN_REQUEST_URL")

    if (auth_token):
        # All three are set. bad bad!
        if (api_token and auth_token):
            raise EnvironmentError('[ENV VARIABLES] please set either "AUTH_TOKEN" or "API_TOKEN". Not both.')
        # Only TOKEN is set. good.
        else:
            return auth_token
    else:
        # Nothing is set. bad!
        if not (api_token and token_request_url):
            raise EnvironmentError('[ENV VARIABLES] Please set "API_TOKEN" as "AUTH_TOKEN" is not set.')
        # Only USERNAME, PASSWORD are set. good.
        else:
            token_response = requests.post(token_request_url, data={"apikey": api_token, "grant_type": 'urn:ibm:params:oauth:grant-type:apikey'})
            if token_response.status_code == 200:
                return token_response.json()["access_token"]
            else:
                raise Exception(f"Authentication returned {token_response.status_code}: {token_response.text}")

dir_path = os.path.dirname(os.path.realpath(__file__))
UPLOAD_FOLDER = dir_path + '/uploads'
# STATIC_FOLDER = dir_path + '/static'
# UPLOAD_FOLDER = 'uploads'
STATIC_FOLDER = 'static'


model = load_model('model111.h5')
# model222=load_model("my_model.h5")

#FOR THE FIRST MODEL

# call model to predict an image
def api(full_path):
    data = image.load_img(full_path, target_size=(50, 50, 3))
    data = np.expand_dims(data, axis=0)
    data = data * 1.0 / 255

    #with graph.as_default():
    predicted = model.predict(data)
    return predicted


# procesing uploaded file and predict it
@app.route('/upload', methods=['POST','GET'])
def upload_file():

    if request.method == 'GET':
        return render_template('index.html')
    else:
        try:
            file = request.files['image']
            full_name = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(full_name)

            indices = {0: 'PARASITIC', 1: 'Uninfected', 2: 'Invasive carcinomar', 3: 'Normal'}
            result = api(full_name)
            print(result)

            predicted_class = np.asscalar(np.argmax(result, axis=1))
            accuracy = round(result[0][predicted_class] * 100, 2)
            label = indices[predicted_class]
            return render_template('predict.html', image_file_name = file.filename, label = label, accuracy = accuracy)
        except Exception as e:
            print("error is:", e)
            flash("Please select the image first !!", "danger")      
            return redirect(url_for("Malaria"))



@app.route('/uploads/<filename>')
def send_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)



class riskForm():

    @app.route('/result', methods=['GET', 'POST'])
    def index():
        

        if request.method == 'POST':
            ID = 999

            session['ID'] = ID
            data = {}

            for k, v in request.form.items():
                data[k] = v
                session[k] = v
            
        
            
            scoring_href = os.environ.get('MODEL_URL')

            if not (scoring_href):
                raise EnvironmentError('[ENV VARIABLES] Please set "URL".')

            for field in ints.keys():
                data[field] = int(data[field])
            for field in floats.keys():
                data[field] = float(data[field])

            input_data = list(data.keys())
            input_values = list(data.values())

            # Inject fields into payload to match model input schema
            extra_fields = os.environ.get('EXTRA_FIELDS').split(',')
            #print(extra_fields)
            i = 0
            for f in extra_fields:
                if f:
                    input_data.insert(i, f)
                    input_values.insert(i, None)
                    i += 1

            payload_scoring = {"input_data": [
                {"fields": input_data, "values": [input_values]}
            ]}
            # print("Payload is: ")
            # print(payload_scoring)
        
            header_online = {
                'Cache-Control': 'no-cache',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + get_token()
            }
            response_scoring = requests.post(
                scoring_href,
                verify=True,
                json=payload_scoring,
                headers=header_online)
            result = response_scoring.text
            # print("Result is ", result)
            result_json = json.loads(result)
        
            result_keys = result_json['predictions'][0]['fields']
            result_vals = result_json['predictions'][0]['values']
        
            result_dict = dict(zip(result_keys, result_vals[0]))
        
        
                
            health_risk = ''
            # if "predictedLabel" in result_dict:
            #     health_risk = result_dict["predictedLabel"]
            if "health_status" in result_dict:
                health_risk = result_dict["health_status"]
                if health_risk=="Unhealthy":
                    health_status_risk = float(result_dict["Probability"])* 100
                    # healthy_percent=100-unhealthy_percent
                    health_risk_percent="{:.2f}".format(health_status_risk)
                
                elif health_risk=="Healthy":  
                    healthy_percent = float(result_dict["Probability"])* 100
                    health_status_risk=100-healthy_percent
                    health_risk_percent="{:.2f}".format(health_status_risk)
                #     flash('Percentage of this health representing risk is: %.2f%%'
                # % health_risk_percent)
            
            return render_template(
                'results.html', 
                status=health_risk,
                health_risk_percent=health_risk_percent)
                
        else:
            return render_template("fullbody.html" , message="Please register to use services.")

                
    @app.route("/")    
    @app.route("/home")
    def home():
        return render_template("home.html")
 


    @app.route("/about")
    def about():
        return render_template("about.html")

    @app.route("/fullbody")
    def fullbody():
        return render_template("fullbody.html")

    @app.route("/cancer")
    def cancer():
        return render_template("cancer.html")


    @app.route("/diabetes")
    def diabetes():
        #if form.validate_on_submit():
        return render_template("diabetes.html")

    @app.route("/heart")
    def heart():
        return render_template("heart.html")


    @app.route("/liver")
    def liver():
        #if form.validate_on_submit():
        return render_template("liver.html")

    @app.route("/kidney")
    def kidney():
        #if form.validate_on_submit():
        return render_template("kidney.html")

    @app.route("/Malaria")
    def Malaria():
        return render_template("index.html")

    @app.route("/Pneumonia")
    def Pneumonia():
        return render_template("index2.html")

    @app.route("/login")
    def login():
        return render_template("login.html")

    @app.route("/register",methods=["GET"])
    def register1():
        return render_template("register.html")

    @app.route("/register", methods=["POST"])
    def register():
        data = {}
        for k , v in request.form.items():
            data[k] = v
        print(data)
        # return render_template("register.html",message="successfully registered")
        regID = str(uuid.uuid1()).split(sep='-')[0]
        send_mail(data['First Name'], regID,"ks12april@gmail.com", data['Email'], "enafrgroelydoufv")
        
        return render_template("register.html" , message=f"Registration Successfull!!Your Registration No. is {regID}")

    

load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))
port = os.environ.get('PORT', '5000')
host = os.environ.get('HOST', '0.0.0.0')
if __name__ == "__main__":
    app.run(host=host, port=int(port))
